<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Team;

class TeamController extends Controller
{
    public function create(Request $req){
        $data = new Team();
        $data->team_name=$req->name;
        $result=$data->save();

        if($req){
            return redirect('/team');
        }
        else {
            return "done done";
        }
    }

    public function list(){
        
        $result = Team::all();
        return view('team.team', compact('result'));
    }

    public function edit($id)
    {  
        $data=Team::find($id);
        return view('team.team', compact('data'));
    }

     public function EditMember(Request $req,$id)
      {
          $data=Team::find($id);
          $data->team_name=$req->name;
          if($data->save()){
            return redirect('/team');
          }
          else{
              echo "error";
          }
      }

      public function delete($id)
     {
        echo $isDeleted=Team::destroy($id);

         if($isDeleted){
         return redirect('/team');
         }  
     }
}
