<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserloginController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\LeadsController;

Route::get('/', function () {
    return view('welcome');
});

// Route::controller(AdminLoginController::class)->group(function() {
//     Route::get('/register', 'register')->name('register');
//     Route::post('/store', 'store')->name('store');
//     Route::get('/login', 'login')->name('login');
//     Route::post('/authenticate', 'authenticate')->name('authenticate');
//     Route::get('/home', 'home')->name('home');
//     Route::post('/logout', 'logout')->name('logout');
// });

Route::controller(AdminController::class)->group(function() {
   // Route::get('/register', 'register')->name('register');
    Route::post('/store', 'store')->name('store');
    Route::get('/login', 'login')->name('login');
    Route::post('/authenticate', 'authenticate')->name('authenticate');
    Route::get('/authenticate', 'authenticate')->name('authenticate');
    Route::get('/home', 'home')->name('home');
   // Route::get('/home','index'])->name('admin.home');
    Route::post('/logout', 'logout')->name('logout');
    
});

Route::post('user',[UserController::class,'data']);
Route::view('user','user.user');
 Route::view('user','user.user');
 Route::get('user',[UserController::class,'list']);
// Route::get('/user/{id}',[RoleController::class,'edit']); 
 Route::get('user/{id}', [UserController::class, 'edit']);
 Route::post('/user', [UserController::class, 'store']);

Route::put('user/{id}',[UserController::class,'update']); 
 // web.php
 //Route::get('/delete/{id}', [UserController::class, 'delete'])->name('user');


 
//  Auth::routes();
// Route::view('registration','auth.registration');
// Route::view()
//  Route::view('insert',[UserController::class,'roles.roles']); 
// Route::view('permission','roles.permission');
// Route::get('roles',[RoleController::class,'create']);
//Route::view('insert','roles.insert');

// Auth::routes();
// Route::group(['middleware' => ['auth']], function() {
//     Route::resource('roles.roles', RoleController::class);
    //Route::resource('roles', RoleController::class);

//     Route::resource('users', UserController::class);
// });

// Route::middleware(['auth'])->group(function () {
//     Route::resource('roles.roles', RoleController::class);
// });

Auth::routes();

 Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::group(['middleware' => ['auth']], function() {
     Route::resource('roles', RoleController::class);
     Route::resource('users', UserController::class);
    
 });

 // Add this for anchor-based deletion
Route::get('/roles/delete/{id}', [App\Http\Controllers\RoleController::class, 'destroy'])->name('roles.roles');
Route::get('/users/delete/{id}', [App\Http\Controllers\UserController::class, 'delete'])->name('users.users');

// Route::get('/destroy/{id}',[RoleController::class,'destroy']); 

 //Route::get('/role/{id}',[RoleController::class,'destroy']); 

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
//Route::view('team','team.team');
//Route::get('/team', [TeamController::class, 'createForm']);
Route::post('/team', [TeamController::class, 'create']);
Route::get('/team', [TeamController::class, 'list']);
Route::get('/team/{id}', [TeamController::class, 'edit']);
Route::put('/team/{id}', [TeamController::class, 'EditMember']);
Route::get('destroy/{id}',[TeamController::class,'delete']);
// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
// Route::view('rolesss','roles.roless');
Route::post('/lead', [LeadsController::class, 'create']);
Route::get('/lead', [LeadsController::class, 'list']);
Route::get('/lead/{id}', [LeadsController::class, 'edit']);
Route::put('/lead/{id}', [LeadsController::class, 'EditMember']);
Route::get('delete/{id}',[LeadsController::class,'delete']);