

<div class="layout-page">
  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">

      <!-- Add New Record Offcanvas -->
      <div class="card">
        <div class="offcanvas offcanvas-end" id="add-new-record">
          <div class="offcanvas-header border-bottom">
            <h5 class="offcanvas-title">New Record</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>

          <div class="offcanvas-body flex-grow-1">
            <form class="add-new-record pt-0 row g-2" method="post" action="">
              <?php echo csrf_field(); ?>

              <div class="col-sm-12 form-control-validation">
                <label class="form-label" for="basicFullname">Team Name</label>
                <div class="input-group input-group-merge">
                  <span id="basicFullname2" class="input-group-text">
                    <i class="icon-base ti tabler-user"></i>
                  </span>
                  <input
                    type="text"
                    id="basicFullname"
                    class="form-control dt-full-name"
                    name="name"
                    placeholder="John Doe"
                    aria-label="John Doe"
                    aria-describedby="basicFullname2"
                  />
                </div>
              </div>

              <div class="col-sm-12 form-control-validation">
                <!-- Optional additional role field can go here -->
                <div class="input-group input-group-merge"></div>
              </div>

              <div class="col-sm-12">
                <button type="submit" class="btn btn-primary data-submit me-sm-4 me-1">Submit</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">Cancel</button>
              </div>
            </form>
          </div>
        </div>

        <!-- Table Section -->
        <div class="card-datatable text-nowrap">
          <div class="row card-header flex-column flex-md-row mx-0 px-3">
            <div class="d-md-flex justify-content-between align-items-center dt-layout-start col-md-auto me-auto mt-0">
              <h5 class="card-title mb-0 text-md-start text-center pb-md-0 pb-6">Team Detail</h5>
            </div>
            <div class="d-md-flex justify-content-between align-items-center dt-layout-end col-md-auto ms-auto mt-0">
              <div class="dt-buttons btn-group flex-wrap mb-0">
                <div class="btn-group">
                  <button class="btn buttons-collection btn-label-primary dropdown-toggle me-4" type="button">
                    <span class="d-flex align-items-center gap-2">
                      <span class="d-none d-sm-inline-block">Export</span>
                    </span>
                  </button>
                  <button
                    type="button"
                    class="btn btn-primary ms-auto"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#add-new-record"
                  >
                    <i class="icon-base ti tabler-plus icon-sm"></i>
                    <span class="d-none d-sm-inline-block">Add New Record</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          <br />

          <table class="dt-complex-header table table-responsive">
            <thead class="text-center fw-bold">
              <tr>
                <th>Team_No.</th>
                <th>Team Name</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="table-border-bottom-0">
              <?php $i = 1; ?>
              <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="text-center">
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($data->team_name); ?></td>
                <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                      <i class="icon-base ti tabler-dots-vertical"></i>
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="/team/<?php echo e($data->id); ?>" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($data->id); ?>">
                        <i class="icon-base ti tabler-pencil me-1"></i> Edit
                      </a>
                      <a class="dropdown-item" href="/destroy/<?php echo e($data->id); ?>" onclick="return confirm('Are you sure you want to delete ?');">
                        <i class="icon-base ti tabler-trash me-1"></i> Delete
                      </a>

                      
                    </div>
                  </div>
                </td>
              </tr>

              <?php if(session('success')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
              <?php endif; ?>

              <!-- Edit Modal -->
              <div class="modal fade" id="editModal<?php echo e($data->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($data->id); ?>" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" style="max-width: 70%;">
                  <div class="modal-content">
                    <form action="<?php echo e(url('team/'.$data->id)); ?>" id="EditForm<?php echo e($data->id); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('PUT'); ?>

                      <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel<?php echo e($data->id); ?>">Update Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>

                      <div class="modal-body">
                        <div class="mb-12">
                          <label for="editName" class="form-label">Team Name</label>
                          <input
                            type="text"
                            class="form-control"
                            id="editName"
                            name="name"
                            value="<?php echo e(old('name', $data->name)); ?>"
                            required
                          />
                        </div>
                      </div>

                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" form="EditForm<?php echo e($data->id); ?>" class="btn btn-primary">Save Changes</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

      

      <?php if(isset($openModal) && $openModal): ?>
      <script>
        window.onload = function () {
          var editModal = new bootstrap.Modal(document.getElementById('editModal'));
          editModal.show();
        };
      </script>
      <?php endif; ?>



    </div>
  </div>
</div>



<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\first-app\my_first_app\ERP_APP\resources\views/team/team.blade.php ENDPATH**/ ?>