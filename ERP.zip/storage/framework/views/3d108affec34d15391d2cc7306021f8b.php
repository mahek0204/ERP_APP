
          <!-- / Navbar -->
<div class="layout-page">
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="mb-1">Roles List</h4>

              <p class="mb-6">
                A role provided access to predefined menus and features so that depending on <br />
                assigned role an administrator can have access to what user needs.
              </p>
              <!-- Role cards -->
              <div class="row g-6">
                <div class="col-xl-12 col-lg-12 col-md-6">
                  <div class="card">
                    <!-- <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="fw-normal mb-0 text-body">Total 4 users</h6>
                        <ul class="list-unstyled d-flex align-items-center avatar-group mb-0">
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Vinnie Mostowy"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/5.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Allen Rieske"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/12.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Julee Rossignol"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/6.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Kaith D'souza"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/3.png" alt="Avatar" />
                          </li>
                        </ul>
                      </div>
                      <div class="d-flex justify-content-between align-items-end">
                        <div class="role-heading">
                          <h5 class="mb-1">Administrator</h5>
                          <a
                            href="javascript:;"
                            data-bs-toggle="modal"
                            data-bs-target="#addRoleModal"
                            class="role-edit-modal"
                            ><span>Edit Role</span></a
                          >
                        </div>
                        <a href="javascript:void(0);"><i class="icon-base ti tabler-copy icon-md text-heading"></i></a>
                      </div>
                    </div> -->
                  </div>
                </div>
                <!-- <div class="col-xl-4 col-lg-6 col-md-6">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="fw-normal mb-0 text-body">Total 7 users</h6>
                        <ul class="list-unstyled d-flex align-items-center avatar-group mb-0">
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Jimmy Ressula"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/4.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="John Doe"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/1.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Kristi Lawker"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/2.png" alt="Avatar" />
                          </li>
                          <li class="avatar">
                            <span
                              class="avatar-initial rounded-circle pull-up"
                              data-bs-toggle="tooltip"
                              data-bs-placement="bottom"
                              title="4 more"
                              >+4</span
                            >
                          </li>
                        </ul>
                      </div>
                      <div class="d-flex justify-content-between align-items-end">
                        <div class="role-heading">
                          <h5 class="mb-1">Manager</h5>
                          <a
                            href="javascript:;"
                            data-bs-toggle="modal"
                            data-bs-target="#addRoleModal"
                            class="role-edit-modal"
                            ><span>Edit Role</span></a
                          >
                        </div>
                        <a href="javascript:void(0);"><i class="icon-base ti tabler-copy icon-md text-heading"></i></a>
                      </div>
                    </div>
                  </div>
                </div> -->
                <!-- <div class="col-xl-4 col-lg-6 col-md-6">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="fw-normal mb-0 text-body">Total 5 users</h6>
                        <ul class="list-unstyled d-flex align-items-center avatar-group mb-0">
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Andrew Tye"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/6.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Rishi Swaat"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/9.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Rossie Kim"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/12.png" alt="Avatar" />
                          </li>
                          <li class="avatar">
                            <span
                              class="avatar-initial rounded-circle pull-up"
                              data-bs-toggle="tooltip"
                              data-bs-placement="bottom"
                              title="2 more"
                              >+2</span
                            >
                          </li>
                        </ul>
                      </div>
                      <div class="d-flex justify-content-between align-items-end">
                        <div class="role-heading">
                          <h5 class="mb-1">Users</h5>
                          <a
                            href="javascript:;"
                            data-bs-toggle="modal"
                            data-bs-target="#addRoleModal"
                            class="role-edit-modal"
                            ><span>Edit Role</span></a
                          >
                        </div>
                        <a href="javascript:void(0);"><i class="icon-base ti tabler-copy icon-md text-heading"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-md-6">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="fw-normal mb-0 text-body">Total 3 users</h6>
                        <ul class="list-unstyled d-flex align-items-center avatar-group mb-0">
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Kim Karlos"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/3.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Katy Turner"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/9.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Peter Adward"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/4.png" alt="Avatar" />
                          </li>
                          <li class="avatar">
                            <span
                              class="avatar-initial rounded-circle pull-up"
                              data-bs-toggle="tooltip"
                              data-bs-placement="bottom"
                              title="3 more"
                              >+3</span
                            >
                          </li>
                        </ul>
                      </div>
                      <div class="d-flex justify-content-between align-items-end">
                        <div class="role-heading">
                          <h5 class="mb-1">Support</h5>
                          <a
                            href="javascript:;"
                            data-bs-toggle="modal"
                            data-bs-target="#addRoleModal"
                            class="role-edit-modal"
                            ><span>Edit Role</span></a
                          >
                        </div>
                        <a href="javascript:void(0);"><i class="icon-base ti tabler-copy icon-md text-heading"></i></a>
                      </div>
                    </div>
                  </div>
                </div> -->
                <!-- <div class="col-xl-4 col-lg-6 col-md-6">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="fw-normal mb-0 text-body">Total 2 users</h6>
                        <ul class="list-unstyled d-flex align-items-center avatar-group mb-0">
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Kim Merchent"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/10.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Sam D'souza"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/13.png" alt="Avatar" />
                          </li>
                          <li
                            data-bs-toggle="tooltip"
                            data-popup="tooltip-custom"
                            data-bs-placement="top"
                            title="Nurvi Karlos"
                            class="avatar pull-up">
                            <img class="rounded-circle" src="../../assets/img/avatars/5.png" alt="Avatar" />
                          </li>
                          <li class="avatar">
                            <span
                              class="avatar-initial rounded-circle pull-up"
                              data-bs-toggle="tooltip"
                              data-bs-placement="bottom"
                              title="7 more"
                              >+7</span
                            >
                          </li>
                        </ul>
                      </div>
                      <div class="d-flex justify-content-between align-items-end">
                        <div class="role-heading">
                          <h5 class="mb-1">Restricted User</h5>
                          <a
                            href="javascript:;"
                            data-bs-toggle="modal"
                            data-bs-target="#addRoleModal"
                            class="role-edit-modal"
                            ><span>Edit Role</span></a
                          >
                        </div>
                        <a href="javascript:void(0);"><i class="icon-base ti tabler-copy icon-md text-heading"></i></a>
                      </div>
                    </div>
                  </div>
                </div> -->
                <div class="col-xl-4 col-lg-6 col-md-6">
                  <div class="card h-100">
                    <div class="row h-100">
                      <div class="col-sm-5">
                        <div class="d-flex align-items-end h-100 justify-content-center mt-sm-0 mt-4">
                          <img
                            src="../../assets/img/illustrations/add-new-roles.png"
                            class="img-fluid"
                            alt="Image"
                            width="83" />
                        </div>
                      </div>
                      <div class="col-sm-7">
                        <div class="card-body text-sm-end text-center ps-sm-0">
                          
                          <!-- <p class="mb-0">
                            Add new role, <br />
                            if it doesn't exist.
                          </p> -->
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- <div class="col-12"> -->
                  <!-- <h4 class="mt-6 mb-1">Total users with their roles</h4>
                  <p class="mb-0">Find all of your company’s administrator accounts and their associate roles.</p> -->
                <!-- </div> -->
                <div class="col-12">
                  <!-- Role Table -->
                  <div class="card">
                    <div class="card-datatable">
                      <table class="datatables-users table border-top">
                        <thead>
                      <tr><h4 class="mt-6 mb-1">Total users with their roles</h4><button
                            data-bs-target="#addRoleModal"
                            data-bs-toggle="modal"
                            class="btn btn-sm btn-primary mb-4 text-nowrap add-new-role">
                            Add New Role
                          </button></tr>  
                          <tr>
                            
                            <th>User</th>
                            <th>Role</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($role->name); ?></td>
        <td>
            <a class="btn btn-info btn-sm" href="<?php echo e(route('roles.show',$role->id)); ?>"><i class="fa-solid fa-list"></i> Show</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('roles.edit',$role->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
            <form method="POST" action="<?php echo e(route('roles.destroy', $role->id)); ?>" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
            </form>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td></td>
        <td><?php echo e($role->name); ?></td>
                        <td>
                          <div class="dropdown">
                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                              <i class="icon-base ti tabler-dots-vertical"></i>
                            </button>
                            <div class="dropdown-menu">   
                            <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($role->id); ?>">
                            <i class="icon-base ti tabler-pencil me-1"></i> Edit
                            </a>
                              <a class="dropdown-item" href="/delete/<?php echo e($role->id); ?>" onclick="return confirm('Are you sure you want to delete ?');"
                                ><i class="icon-base ti tabler-trash me-1"></i> Delete</a
                              >
                              </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                      </table>
                    </div>
                  </div>
                  <!--/ Role Table -->
                </div>
              </div>
              <!--/ Role cards -->

              <!-- Add Role Modal -->
              <!-- Add Role Modal -->
              <div class="modal fade" id="addRoleModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-simple modal-dialog-centered modal-add-new-role">
                  <div class="modal-content">
                    <div class="modal-body">
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      <div class="text-center mb-6">
                        <h4 class="role-title">Add New Role</h4>
                        <p class="text-body-secondary">Set role permissions</p>
                      </div>
                      <!-- Add role form -->
                      <form id="addRoleForm" class="row g-3" onsubmit="return false">
                        <div class="col-12 form-control-validation mb-3">
                          <label class="form-label" for="modalRoleName">Role Name</label>
                          <input
                            type="text"
                            id="modalRoleName"
                            name="name"
                            class="form-control"
                            placeholder="Enter a role name"
                            tabindex="-1" />
                        </div>
                        <div class="col-12">
                          <h5 class="mb-6">Role Permissions</h5>
                          <strong>Permission:</strong>
                <br/>
                <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label><input type="checkbox" name="permission[<?php echo e($value->id); ?>]" value="<?php echo e($value->id); ?>" class="name">
                    <?php echo e($value->name); ?></label>
                <br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        <div class="col-12 text-center">
                          <button type="submit" class="btn btn-primary me-sm-4 me-1">Submit</button>
                          <button
                            type="reset"
                            class="btn btn-label-secondary"
                            data-bs-dismiss="modal"
                            aria-label="Close">
                            Cancel
                          </button>
                        </div>
                      </form>
                      <!--/ Add role form -->
                    </div>
                  </div>
                </div>
              </div>
              <!--/ Add Role Modal -->

              <!-- / Add Role Modal -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            
<?php echo $__env->make('layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\first-app\my_first_app\ERP_APP\resources\views/roles/roless.blade.php ENDPATH**/ ?>